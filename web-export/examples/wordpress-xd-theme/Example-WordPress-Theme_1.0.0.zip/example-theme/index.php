<!DOCTYPE html>
<html <?php language_attributes(); ?>
<head>
<meta charset="utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
<title><?php $title = trim( wp_title( ' ', FALSE ) ); print ''=== $title ? get_bloginfo( 'name' ) : $title; ?></title>
<?php wp_head(); ?>
<style id="applicationStylesheet" type="text/css">
	body {
		margin: 0;
		padding: 0;
	}
	:root {
		--web-view-ids: Wordpress_Theme_Example;
	}
	#Wordpress_Theme_Example * {
		margin: 0;
		padding: 0;
	}
	#Wordpress_Theme_Example {
		position: absolute;
		box-sizing: border-box;
		transform: translateX(-50%);
		left: 50%;
		background: #E5E5E5;
		width: 620px;
		height: 905px;
		background-color: rgba(255,255,255,1);
		overflow: hidden;
		margin: 0;
		padding: 0;
		opacity: 1;
		--web-view-name: Wordpress Theme Example;
		--web-view-id: Wordpress_Theme_Example;
		--web-enable-deep-linking: true;
	}
	#Helvetica_Neues {
		opacity: 1;
		position: absolute;
		left: 30px;
		top: 25px;
		box-sizing: border-box;
		margin: 0;
		padding: 0;
		width: 232px;
		height: 36px;
		overflow: visible;
		text-align: left;
		font-family: Helvetica Neue;
		font-style: normal;
		font-weight: bold;
		font-size: 30px;
		color: rgba(112,112,112,1);
	}
	#Rectangle_1 {
		opacity: 1;
		position: absolute;
		left: 30px;
		top: 89px;
		box-sizing: border-box;
		margin: 0;
		padding: 0;
		width: 560px;
		height: 315px;
		overflow: visible;
	}
	#Lorem_ipsum_dolor_sit_amet__co {
		opacity: 1;
		position: absolute;
		left: 30px;
		top: 429px;
		box-sizing: border-box;
		margin: 0;
		padding: 0;
		width: 260px;
		height: 454px;
		overflow: visible;
		line-height: 20px;
		margin-top: -3.5px;
		text-align: left;
		font-family: Helvetica Neue;
		font-style: normal;
		font-weight: normal;
		font-size: 13px;
		color: rgba(112,112,112,1);
	}
	#Lorem_ipsum_dolor_sit_amet__co_A0_Text_3 {
		opacity: 1;
		position: absolute;
		left: 330px;
		top: 429px;
		box-sizing: border-box;
		margin: 0;
		padding: 0;
		overflow: hidden;
		width: 261px;
		height: 399px;
		line-height: 20px;
		margin-top: -3.5px;
		text-align: left;
		font-family: Helvetica Neue;
		font-style: normal;
		font-weight: normal;
		font-size: 13px;
		color: rgba(112,112,112,1);
	}
	#Line_1 {
		opacity: 1;
		fill: transparent;
		stroke: rgb(112, 112, 112);
		stroke-width: 1px;
		stroke-linejoin: miter;
		stroke-linecap: butt;
		stroke-miterlimit: 4;
		shape-rendering: auto;
	}
	.Line_1 {
		overflow: visible;
		position: absolute;
		top: 66.5px;
		left: 30px;
		width: 560px;
		height: 1px;
	}
	#Lorem_ipsum {
		opacity: 1;
		position: absolute;
		right: 53px;
		top: 46px;
		box-sizing: border-box;
		margin: 0;
		padding: 0;
		width: initial;
		height: 12px;
		overflow: visible;
		text-align: left;
		font-family: Helvetica Neue;
		font-style: normal;
		font-weight: normal;
		font-size: 11px;
		color: rgba(112,112,112,1);
	}
	#Ellipse_1 {
		opacity: 1;
		fill: url(#Ellipse_1_A0_Ellipse_2_pattern);
	}
	.Ellipse_1 {
		position: absolute;
		overflow: visible;
		width: 14px;
		height: 14px;
		left: 575px;
		top: 45px;
	}
</style>
<base href="<?php echo get_stylesheet_directory_uri() ?>/"/>
</head>
<div>
<div id="Wordpress_Theme_Example">
	<div id="Helvetica_Neues">
		<? echo get_bloginfo( 'name' ) ?>
	</div>
	<div id="Rectangle_1">
		<iframe width="560" height="315" src="https://www.youtube.com/embed/j5MKk_QRBAY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
		</div>
	<div id="Lorem_ipsum_dolor_sit_amet__co">
		<?php the_post(); echo the_content(); ?>
	</div>
	<div id="Lorem_ipsum_dolor_sit_amet__co_A0_Text_3">
		<span>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<br/>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna.</span>
	</div>
	<svg class="Line_1">
		<path id="Line_1" d="M 0 0 L 560 0">
		</path>
	</svg>
	<div id="Lorem_ipsum">
		<? echo get_bloginfo( 'description', 'display' ) ?>
	</div>
	<svg class="Ellipse_1">
		<pattern elementId="Ellipse_1_A0_Ellipse_2" id="Ellipse_1_A0_Ellipse_2_pattern" x="0" y="0" width="100%" height="100%">
			<image x="0" y="0" width="100%" height="100%" href="Ellipse_1_A0_Ellipse_2_pattern.png" xlink:href="Ellipse_1_A0_Ellipse_2_pattern.png"></image>
		</pattern>
		<ellipse id="Ellipse_1" rx="7" ry="7" cx="7" cy="7">
		</ellipse>
	</svg>
</div>
</body>
<?php wp_footer(); ?>